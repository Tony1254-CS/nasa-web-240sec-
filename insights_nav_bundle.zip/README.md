# FluviSAR - Insights Navigation & Impact Assessment Module

This package contains all components, styles, state management, and mock/provenance data related to the **Insights** navigation tab (`/impact`) in FluviSAR.

---

## 📁 Package Structure

```
insights_bundle/
├── README.md
├── src/
│   ├── components/
│   │   └── Navbar.tsx            # Navigation bar containing the 'Insights' tab with AlertTriangle icon & active states
│   ├── pages/
│   │   └── Impact.tsx            # Full-featured Insights / Impact Assessment page (/impact)
│   ├── panels/
│   │   ├── ForecastImpact.tsx    # Impact & Forecast datasets (IMPACT_DATA, FORECAST_DATA) & ImpactDashboard widget
│   │   └── EvidenceTabs.tsx      # Evidence tab definitions & embedded ImpactPanel
│   ├── state/
│   │   └── store.ts              # Zustand store for reachId, sensory modes, and global states
│   └── styles/
│       ├── impact.css            # Styles for KPI strip, Sendai framework indicators, DaLA ledger, charts, modal
│       ├── navbar.css            # Navigation bar and menu dropdown styling
│       ├── base.css              # Color tokens, glassmorphism utilities, layout grids
│       ├── tokens.css            # Design system tokens and CSS variables
│       └── globe.css             # Background ambient glow, animations, and theme styles
└── public/
    └── data/
        └── v1/                   # Reach datasets loaded dynamically by the Insights page
            ├── reaches.json      # Available reach metadata
            ├── jamuna-chilmari/  # Manifest & QC files for Jamuna reach
            ├── glacier-bay-alaska/
            ├── norcal-wildfire/
            └── sundarbans-mangrove/
```

---

## 🌟 Key Features in this Module

1. **Mission Status & Reach Selector**:
   - Allows switching between reaches (`jamuna-chilmari`, `glacier-bay-alaska`, `norcal-wildfire`, `sundarbans-mangrove`).
   - Fetches and displays actual manifest and QC audit logs per reach.

2. **Sendai Framework Indicators (2015–2030)**:
   - Target B: Affected Population & Dwellings Damaged/Destroyed.
   - Target C: Direct Economic Loss & Agricultural Exposure.

3. **World Bank DaLA (Damage and Loss Assessment) Economic Ledger**:
   - Categorized breakdown of Direct Physical Damage (Homesteads, Land, Flood Control) and Economic Flow Losses (Lost harvests, relocation).

4. **Temporal Economic Decay Trajectory**:
   - SVG-rendered multi-line chart depicting physical infrastructure loss and cascading economic flow losses over time.

5. **Community Action Matrix & Emergency Briefing**:
   - Priority-ranked response actions (Evacuation, Prepositioning, Monitoring).
   - Interactive modal that generates emergency briefings with one-click clipboard copying.
